package com.example.lab1_gtics_20251_20224926;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1Gtics2025120224926Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab1Gtics2025120224926Application.class, args);
	}

}
