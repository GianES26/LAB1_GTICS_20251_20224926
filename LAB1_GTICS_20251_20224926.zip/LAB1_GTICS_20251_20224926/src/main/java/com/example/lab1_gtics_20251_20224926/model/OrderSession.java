package com.example.lab1_gtics_20251_20224926.model;

import lombok.Getter;

@Getter
public class OrderSession {
    private final OrderConfig order;
    private final double total;

    public OrderSession(OrderConfig order, double total) {
        this.order = order;
        this.total = total;
    }
}
