package com.example.lab1_gtics_20251_20224926;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1Gtics2025120224926ApplicationTests {

	@Test
	void contextLoads() {
	}

}
