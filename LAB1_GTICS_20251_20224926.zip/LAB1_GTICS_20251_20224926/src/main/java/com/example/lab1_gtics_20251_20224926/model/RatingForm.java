package com.example.lab1_gtics_20251_20224926.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RatingForm {
    private int estrellas;
    private String comentario;
}
