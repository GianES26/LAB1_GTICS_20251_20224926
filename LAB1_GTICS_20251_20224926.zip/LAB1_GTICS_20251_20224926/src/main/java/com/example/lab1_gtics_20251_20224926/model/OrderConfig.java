package com.example.lab1_gtics_20251_20224926.model;

import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
public class OrderConfig {
    private String nombre;
    private String mesa;
    private List<Producto> productos;

    @Getter
    @Setter
    public static class Producto {
        private String tipo;
        private String tamaño;
        private Integer cantidad;
        private List<String> adicionales;
    }
}
