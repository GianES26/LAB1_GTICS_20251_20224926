package com.example.lab1_gtics_20251_20224926.controller;

import com.example.lab1_gtics_20251_20224926.model.OrderConfig;
import com.example.lab1_gtics_20251_20224926.model.OrderSession;
import com.example.lab1_gtics_20251_20224926.model.RatingForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@Controller
@SessionAttributes("orderSession")
public class PedidoController {

    @GetMapping("/pedido")
    public String mostrarFormulario(Model model) {
        OrderConfig orderConfig = new OrderConfig();
        orderConfig.setProductos(new ArrayList<>());
        model.addAttribute("orderConfig", orderConfig);
        return "pedido";
    }

    @PostMapping("/pedido")
    public String procesarPedido(@ModelAttribute OrderConfig orderConfig, Model model) {
        double total = calcularTotal(orderConfig);
        OrderSession session = new OrderSession(orderConfig, total);
        model.addAttribute("orderSession", session);
        model.addAttribute("ratingForm", new RatingForm());
        return "resumen";
    }

    @PostMapping("/calificar")
    public String procesarCalificacion(@ModelAttribute RatingForm ratingForm, Model model) {
        model.addAttribute("mensaje", "¡Gracias por tu calificación de " + ratingForm.getEstrellas() + " estrellas!");
        return "resumen";
    }

    private double calcularTotal(OrderConfig order) {
        if (order.getProductos() == null) {
            return 0.0;
        }

        double base = 10.0;
        double adicional = 1.0;
        return order.getProductos().stream()
                .mapToDouble(p -> base * p.getCantidad() + adicional * (p.getAdicionales() != null ? p.getAdicionales().size() : 0))
                .sum();
    }
}
